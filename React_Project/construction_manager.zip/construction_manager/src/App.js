import logo from './logo.svg';
import Home from './components/Home';
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Registration from './components/Register';
import LoginPage from './components/Login';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <Routes>
    <Route path="/" element={<Home/>} />
    <Route path='/login' element={<LoginPage/>} />
    <Route path="/register" element={<Registration/>} />
  </Routes>
  );
}

export default App;
