import React, { useState } from 'react';
import './Register.css';

const Registration = () => {
  const [formData, setFormData] = useState({
    userId: '',
    name: '',
    email: '',
    password: '',
    roleId: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
  };

  return (
    <main className="App-main">
      <section className="registration">
        <h2>Register</h2>
        <form onSubmit={handleSubmit}>
          <label>
            User ID:
            <input type="text" name="userId" value={formData.userId} onChange={handleChange} required />
          </label>
          <label>
            Name:
            <input type="text" name="name" value={formData.name} onChange={handleChange} required />
          </label>
          <label>
            Email:
            <input type="email" name="email" value={formData.email} onChange={handleChange} required />
          </label>
          <label>
            Password:
            <input type="password" name="password" value={formData.password} onChange={handleChange} required />
          </label>
          <label>
            Role ID:
            <input type="text" name="roleId" value={formData.roleId} onChange={handleChange} required />
          </label>
          <button type="submit">Register</button>
        </form>
      </section>
    </main>
  );
};

export default Registration;
