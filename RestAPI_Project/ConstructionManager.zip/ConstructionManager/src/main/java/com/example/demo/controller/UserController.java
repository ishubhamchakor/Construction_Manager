package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Role;
import com.example.demo.entities.User;
import com.example.demo.entities.UserLoginRequest;
import com.example.demo.repository.RoleRepository;
import com.example.demo.services.UserServices;

@RestController

public class UserController {

	@Autowired
	private UserServices user;
	
	@Autowired
	private RoleRepository urepo;




	@PostMapping("/newUser")
	public ResponseEntity<String> new_user(@RequestBody User ur) {
		if (ur.getRole() == null) {
		    ur.setRole(new Role());
		}
		ur.getRole().setRoleID(3);

			 
		return user.registerUser(ur);
	}
}
