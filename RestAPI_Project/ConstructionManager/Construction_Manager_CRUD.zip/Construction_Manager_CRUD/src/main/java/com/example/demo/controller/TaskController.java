package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.example.demo.entities.Tasks;
import com.example.demo.services.TasksService;

@RestController
@RequestMapping("/tasks") // Base URL for all task operations
@CrossOrigin(origins = "http://localhost:3017") // Allow React frontend access
public class TaskController {

    @Autowired
    private TasksService service;

    // ✅ Fetch all tasks
    @GetMapping("/getAll")
    public List<Tasks> getAllTasks() {
        return service.getAllTasks();
    }

    // ✅ Save a new task with file handling
    @PostMapping("/save")
    public String saveTask(
        @RequestPart("task") Tasks task, // task part
        @RequestPart(value = "fileattachment", required = false) MultipartFile file // file part
    ) {
        return service.saveTask(task, file);
    }
}
