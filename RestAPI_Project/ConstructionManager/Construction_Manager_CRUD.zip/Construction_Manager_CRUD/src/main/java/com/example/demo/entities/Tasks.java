package com.example.demo.entities;

import java.time.LocalDate;
import java.util.List;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "tasks")
public class Tasks {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment in MySQL
    @Column(name = "taskid")
    private Long id;

    @Column(name = "taskname", nullable = false)
    private String taskname;

    @Column(name = "description", nullable = false, columnDefinition = "TEXT")
    private String description;

    @Column(name = "startdate")
    private LocalDate startdate;

    @Column(name = "duedate")
    private LocalDate duedate;

    @Column(name = "priority", nullable = false, length = 50)
    private String priority;

    @Column(name = "status", nullable = false, length = 50)
    private String status;

    @ManyToOne
    @JoinColumn(name = "assignedto", referencedColumnName = "UserID")
    private User assignedto;

    @ManyToOne
    @JoinColumn(name = "assignedby", referencedColumnName = "UserID")
    private User assignedby;

    @Lob
    @Column(name = "fileattachment", columnDefinition = "BLOB")
    private byte[] fileattachment;

    @ManyToOne
    @JoinColumn(name = "projectid", referencedColumnName = "projectid")
    private Project project;

    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Issues> issues;
}
