package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.example.demo.entities.Tasks;
import com.example.demo.repository.TaskRepository;

@Service
public class TasksService {

    @Autowired
    private TaskRepository repo;

    // Save Task with File Handling
    public String saveTask(Tasks task, MultipartFile file) {
        try {
            if (file != null && !file.isEmpty()) {
                task.setFileattachment(file.getBytes());
            }
            repo.save(task);
            return "✅ Task saved successfully!";
        } catch (Exception e) {
            return "❌ Error saving task: " + e.getMessage();
        }
    }

    // Fetch All Tasks
    public List<Tasks> getAllTasks() {
        return repo.findAll();
    }
}
