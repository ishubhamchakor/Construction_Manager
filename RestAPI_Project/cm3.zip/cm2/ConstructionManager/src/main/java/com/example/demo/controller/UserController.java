package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.User;
import com.example.demo.services.UserService;

@RestController

public class UserController {

	@Autowired
	private UserService user;
	
//	@Autowired
//	private RoleRepository urepo;

//	  @PostMapping("/login")
//	    public ResponseEntity<String> login(@RequestBody UserLoginRequest loginRequest) {
//	        // Correct use of roleRepository to find the role
//	        Role role = urepo.findByName(loginRequest.getRole());
//
//	        // Handle the case where the role is not found
//	        if (role == null) {
//	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Role not found.");
//	        }
//
//	        // Validate the user credentials
//	        boolean isValid = user.validateLogin(loginRequest.getName(), loginRequest.getPassword(), role);
//
//	        if (isValid) {
//	            return ResponseEntity.ok("Login successful!");
//	        } else {
//	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username, password, or role.");
//	        }
//	    }


	@PostMapping("/newUser")
	public User new_user(@RequestBody User ur) {
		System.out.println("User : "+ur.toString());
		return user.registerUser(ur);
	}
	
	@GetMapping("/getAllUser")
	public List<User> getAllUser(){
		return user.getAllUser();
		
	}
//
//	 @PutMapping("/forgotpassword")
//	 public ResponseEntity<String> forgot_Password(@RequestBody Forgot_Password fr )
//		   	{
//			   return user.forgot_Password(fr.getUsername(),fr.getEmail(),fr.getPassword() );   
//		   	}
}
