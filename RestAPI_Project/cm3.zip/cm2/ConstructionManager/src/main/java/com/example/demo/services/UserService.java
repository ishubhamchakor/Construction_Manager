package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.User;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Transactional
    public User registerUser(User user) {
//        if (user.getRole() != null && user.getRole().getRoleId() != null) {
//            roleRepository.findById(user.getRole().getRoleId())
//                    .ifPresent(user::setRole);
//        }
    	try {
    		roleRepository.findById(user.getRole().getRoleId());
    	}
    	catch(Exception e)
    	{
    		
    	}
    	
        return userRepository.save(user);
    }
    
   public java.util.List<User> getAllUser(){
		return userRepository.findAll();
	}
}
